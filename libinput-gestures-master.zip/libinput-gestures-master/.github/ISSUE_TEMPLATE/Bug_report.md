---
name: New Issue
about: Create a new issue report

---

Before creating a new issue, please follow each step in the TROUBLESHOOTING section
of the main README.

```
Run libinput-gestures -l on the command line and paste the output here.
```

**Describe the issue**
A clear and concise description of what the issue is.
